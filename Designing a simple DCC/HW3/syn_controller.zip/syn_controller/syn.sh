dc_shell -f controller_syn.tcl | tee da.log
