dc_shell -f TDL_syn.tcl | tee da.log
