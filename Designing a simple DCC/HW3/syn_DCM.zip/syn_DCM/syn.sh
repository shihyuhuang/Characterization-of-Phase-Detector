dc_shell -f DCM_syn.tcl | tee da.log
