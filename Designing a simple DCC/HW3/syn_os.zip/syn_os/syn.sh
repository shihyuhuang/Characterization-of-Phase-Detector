dc_shell -f OS_syn.tcl | tee da.log
