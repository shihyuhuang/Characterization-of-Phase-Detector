uniquifyNetlist -top top DCC_uniquify.v ../../syn_top/top_syn.v
rm -f encounter.*
