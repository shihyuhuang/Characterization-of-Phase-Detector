dc_shell -f syn_top.tcl | tee da.log
