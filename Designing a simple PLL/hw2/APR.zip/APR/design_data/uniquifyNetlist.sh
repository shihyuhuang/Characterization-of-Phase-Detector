uniquifyNetlist -top DLL DLL_uniquify.v DLL_syn.v
rm -f encounter.*
