dc_shell -f DLL_syn.tcl | tee da.log
