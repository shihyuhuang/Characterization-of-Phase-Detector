dc_shell -f pd_syn.tcl | tee da.log
