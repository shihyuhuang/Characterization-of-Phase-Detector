ncverilog testbench.v ../APR/run/DLL_apr.v -v /home/m108/m108061521/process/T90/tsmc090.v +access+r +nc64bit
##rm -rf *.fsdb *.vcd *.bak *.log *.key nWaveLog INCA_libs *.rc *.conf *.history *.svf *.X 
