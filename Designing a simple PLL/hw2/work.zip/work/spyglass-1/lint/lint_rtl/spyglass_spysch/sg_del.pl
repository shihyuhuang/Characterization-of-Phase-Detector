use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("./spyglass-1/lint/lint_rtl/spyglass_spysch/sg_msgtag.txt");
1;