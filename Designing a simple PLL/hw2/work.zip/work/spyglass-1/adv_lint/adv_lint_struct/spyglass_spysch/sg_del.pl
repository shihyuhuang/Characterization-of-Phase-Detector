use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("./spyglass-1/adv_lint/adv_lint_struct/spyglass_spysch/sg_msgtag.txt");
1;